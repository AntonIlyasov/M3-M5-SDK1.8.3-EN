package com.axtech.functiondemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import org.openni.SensorType;
import org.openni.VideoMode;
import org.openni.android.OpenNIView;

import java.util.ArrayList;
import java.util.List;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class DpiActivity extends AppCompatActivity {
    private OpenNIView oni_color, oni_depth, oni_ir;
    private List<VideoMode> colorType, depthType, irType;
    private Spinner sp_color, sp_depth, sp_ir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dpi);
        oni_color = findViewById(R.id.oni_color);
        oni_depth = findViewById(R.id.oni_depth);
        oni_ir = findViewById(R.id.oni_ir);
        sp_color = findViewById(R.id.sp_color);
        sp_depth = findViewById(R.id.sp_depth);
        sp_ir = findViewById(R.id.sp_ir);
        readFrameThread.setOpenNIViewColor(oni_color);
        readFrameThread.setOpenNIViewDepth(oni_depth);
        readFrameThread.setOpenNIViewIr(oni_ir);
        colorType = readFrameThread.getColorStream().getSensorInfo().getSupportedVideoModes();
        depthType = readFrameThread.getDepthStream().getSensorInfo().getSupportedVideoModes();
        irType = readFrameThread.getIrStream().getSensorInfo().getSupportedVideoModes();
        setAdapter(sp_color, colorType,SensorType.COLOR);
        setAdapter(sp_depth, depthType,SensorType.DEPTH);
        setAdapter(sp_ir, irType,SensorType.IR);
    }

    private void setAdapter(Spinner spinner, final List<VideoMode> mStreamVideoModes, final SensorType type) {
        List<CharSequence> videoModesNames = new ArrayList<CharSequence>();
        for (int i = 0; i < mStreamVideoModes.size(); ++i) {
            VideoMode mode = mStreamVideoModes.get(i);
            videoModesNames.add(String.format("%d x %d @ %d FPS (%s)",
                    mode.getResolutionX(),
                    mode.getResolutionY(),
                    mode.getFps(),
                    pixelFormatToName(mode.getPixelFormat())));
        }
        ArrayAdapter<CharSequence> videoModesAdapter = new ArrayAdapter<CharSequence>(this,
                android.R.layout.simple_spinner_item, videoModesNames);
        videoModesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(videoModesAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,int position, long id) {
                switch (type){
                    case IR:
                        readFrameThread.getIrStream().setVideoMode(mStreamVideoModes.get(position));
                        break;
                    case COLOR:
                        readFrameThread.getColorStream().setVideoMode(mStreamVideoModes.get(position));
                        break;
                    case DEPTH:
                        readFrameThread.getDepthStream().setVideoMode(mStreamVideoModes.get(position));
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private CharSequence pixelFormatToName(org.openni.PixelFormat format) {
        switch (format) {
            case DEPTH_1_MM:
                return "1 mm";
            case DEPTH_100_UM:
                return "100 um";
            case DEPTH_1_3_MM:
                return "1/3 mm";
            case SHIFT_9_2:
                return "9.2";
            case SHIFT_9_3:
                return "9.3";
            case RGB888:
                return "RGB";
            case GRAY8:
                return "Gray8";
            case GRAY16:
                return "Gray16";
            case YUV422:
                return "YUV422";
            case YUYV:
                return "YUYV";
            default:
                return "UNKNOWN";
        }
    }
}
