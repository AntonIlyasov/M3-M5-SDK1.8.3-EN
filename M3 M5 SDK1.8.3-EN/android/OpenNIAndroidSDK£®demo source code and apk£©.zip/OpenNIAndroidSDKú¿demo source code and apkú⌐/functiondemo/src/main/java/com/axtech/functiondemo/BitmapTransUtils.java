package com.axtech.functiondemo;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;

import java.nio.ByteBuffer;


/**
 * The type Bitmap trans utils.
 */
public class BitmapTransUtils {

    /**
     * Bitmap 2 rgb byte [ ].
     *
     * @param bitmap the bitmap
     * @return the byte [ ]
     */
    public static byte[] bitmap2RGB(Bitmap bitmap) {
        int bytes = bitmap.getByteCount();  //返回可用于储存此位图像素的最小字节数

        ByteBuffer buffer = ByteBuffer.allocate(bytes); //  使用allocate()静态方法创建字节缓冲区
        bitmap.copyPixelsToBuffer(buffer); // 将位图的像素复制到指定的缓冲区

        byte[] rgba = buffer.array();
        byte[] pixels = new byte[(rgba.length / 4) * 3];

        int count = rgba.length / 4;

        //Bitmap像素点的色彩通道排列顺序是RGBA
        for (int i = 0; i < count; i++) {

            pixels[i * 3] = rgba[i * 4];        //R
            pixels[i * 3 + 1] = rgba[i * 4 + 1];    //G
            pixels[i * 3 + 2] = rgba[i * 4 + 2];       //B

        }

        return pixels;
    }

    /**
     * Bitmap to bgr byte [ ].
     *
     * @param image the image
     * @return the byte [ ]
     */
    public static byte[] bitmapToBgr(Bitmap image) {
        if (image == null) {
            return null;
        }
        int bytes = image.getByteCount();
        ByteBuffer buffer = ByteBuffer.allocate(bytes);
        image.copyPixelsToBuffer(buffer);
        byte[] temp = buffer.array();
        byte[] pixels = new byte[(temp.length / 4) * 3];
        for (int i = 0; i < temp.length / 4; i++) {
            pixels[i * 3] = temp[i * 4 + 2];
            pixels[i * 3 + 1] = temp[i * 4 + 1];
            pixels[i * 3 + 2] = temp[i * 4];
        }
        buffer = null;
        System.gc();
        return pixels;
    }


    /**
     * Bitmap to nv 21 byte [ ].
     *
     * @param src    the src
     * @param width  the width
     * @param height the height
     * @return the byte [ ]
     */
    public static byte[] bitmapToNv21(Bitmap src, int width, int height) {
        if (src != null && src.getWidth() >= width && src.getHeight() >=
                height) {
            int[] argb = new int[width * height];
            src.getPixels(argb, 0, width, 0, 0, width, height);
            return argbToNv21(argb, width, height);
        } else {
            return null;
        }
    }

    private static byte[] argbToNv21(int[] argb, int width, int height) {
        int frameSize = width * height;
        int yIndex = 0;
        int uvIndex = frameSize;
        int index = 0;
        byte[] nv21 = new byte[width * height * 3 / 2];
        for (int j = 0; j < height; ++j) {
            for (int i = 0; i < width; ++i) {
                int R = (argb[index] & 0xFF0000) >> 16;
                int G = (argb[index] & 0x00FF00) >> 8;
                int B = argb[index] & 0x0000FF;
                int Y = (66 * R + 129 * G + 25 * B + 128 >> 8) + 16;
                int U = (-38 * R - 74 * G + 112 * B + 128 >> 8) + 128;
                int V = (112 * R - 94 * G - 18 * B + 128 >> 8) + 128;
                nv21[yIndex++] = (byte) (Y < 0 ? 0 : (Y > 255 ? 255 :
                        Y));
                if (j % 2 == 0 && index % 2 == 0 && uvIndex < nv21.length
                        - 2) {
                    nv21[uvIndex++] = (byte) (V < 0 ? 0 : (V > 255 ? 255 : V));
                    nv21[uvIndex++] = (byte) (U < 0 ? 0 : (U > 255 ?
                            255 : U));
                }
                ++index;
            }
        }
        return nv21;
    }


    /**
     * Rgb 2 bitmap bitmap.
     *
     * @param data   the data
     * @param width  the width
     * @param height the height
     * @return the bitmap
     */
    public static Bitmap rgb2Bitmap(byte[] data, int width, int height) {
        int[] colors = byteRGB2ARGB(data);    //取RGB值转换为int数组
        if (colors == null) {
            return null;
        }
        return Bitmap.createBitmap(colors, 0, width, width, height, Bitmap.Config.ARGB_8888);
    }

    /**
     * Rgb by buffer bitmap.
     *
     * @param rgb the rgb
     * @return the bitmap
     */
    public static Bitmap rgbByBuffer(ByteBuffer rgb) {
        byte[] datas = new byte[rgb.capacity()];
        rgb.get(datas, 0, rgb.capacity());
        rgb.clear();
        return rgb2Bitmap(datas, 640, 480);
    }

    /**
     * Convert byte to int int.
     *
     * @param data the data
     * @return the int
     */
    public static int convertByteToInt(byte data) {
        int heightBit = (int) ((data >> 4) & 0x0F);
        int lowBit = (int) (0x0F & data);
        return heightBit * 16 + lowBit;
    }

    /**
     * Byte rgb 2 argb int [ ].
     *
     * @param data the data
     * @return the int [ ]
     */
    public static int[] byteRGB2ARGB(byte[] data) {
        int[] color = new int[data.length / 3];
        for (int i = 0; i < color.length; ++i) {
            color[i] = (((data[i * 3] & 0xff) << 16) | ((data[i * 3 + 1] & 0xff) << 8) | (data[i * 3 + 2] & 0xff) | 0xFF000000);
        }
        return color;
    }

    /**
     * Convert byte to color int [ ].
     *
     * @param data the data
     * @return the int [ ]
     */
    public static int[] convertByteToColor(byte[] data) {
        int size = data.length;
        if (size == 0) {
            return null;
        }
        int arg = 0;
        if (size % 3 != 0) {
            arg = 1;
        }
        int[] color = new int[size / 3 + arg];
        int red, green, blue;
        int colorLen = color.length;
        if (arg == 0) {
            for (int i = 0; i < colorLen; ++i) {
                red = convertByteToInt(data[i * 3]);
                green = convertByteToInt(data[i * 3 + 1]);
                blue = convertByteToInt(data[i * 3 + 2]);
                color[i] = (red << 16) | (green << 8) | blue | 0xFF000000;
            }
        } else {
            for (int i = 0; i < colorLen - 1; ++i) {
                red = convertByteToInt(data[i * 3]);
                green = convertByteToInt(data[i * 3 + 1]);
                blue = convertByteToInt(data[i * 3 + 2]);
                color[i] = (red << 16) | (green << 8) | blue | 0xFF000000;
            }
            color[colorLen - 1] = 0xFF000000;
        }
        return color;
    }

    /**
     * Conver byte [ ].
     *
     * @param byteBuffer the byte buffer
     * @return the byte [ ]
     */
    public static byte[] conver(ByteBuffer byteBuffer) {
        int len = byteBuffer.limit() - byteBuffer.position();
        byte[] bytes = new byte[len];

        if (byteBuffer.isReadOnly()) {
            return null;
        } else {
            byteBuffer.get(bytes);
        }
        return bytes;
    }

    private static byte[] int4 = new byte[4];
//    private static int[] colors = new int[640 * 480];

    public static Bitmap getBitmapByIr(ByteBuffer buffer,int width, int height) {
        byte[] data = new byte[buffer.capacity()];
        buffer.get(data);
        int[] colors = new int[width * height];
        int z = 0;
        for (byte b : data) {
            colors[z] = ((b & 0xFF)
                    | (b & 0xFF) << 8)
                    | ((b & 0xFF) << 16)
                    | -16777216;
            z++;
        }
        buffer.clear();
        return Bitmap.createBitmap(colors, 0, width, width, height, Bitmap.Config.ARGB_8888);
    }


    public static Bitmap getBitmapByColor(ByteBuffer buffer,int width, int height) {
        byte[] data = new byte[buffer.capacity()];
        buffer.get(data);
        int[] colors = new int[width * height];
        int z = 0;
        for(int i=0;i<data.length;i++){
            if(i%3==0){
                colors[z] = ((data[i+2] & 0xFF)
                        | (data[i+1] & 0xFF) << 8)
                        | (( data[i]& 0xFF) << 16)
                        | -16777216;
                z++;
            }
        }
        buffer.clear();
        return Bitmap.createBitmap(colors, 0, width, width, height, Bitmap.Config.ARGB_8888);
    }
    public static float getDepth(ByteBuffer data, int x, int y, float depthValueUnit_mm) {
        int distance = 0;
        byte[] bytes = new byte[data.capacity()];
        data.get(bytes);
        int[] cdata=new int[640*480];
        int z=0;
        for (int i = 0; i < bytes.length; i++) {
            if(i%2==0){
                cdata[z]=((bytes[i] & 0xFF)
                        | ((bytes[i+1] & 0xFF)<<8));
                z++;
            }
        }
        int cdatum = cdata[y*640 + x];
        float des = cdatum * depthValueUnit_mm;
        return des;
    }
    public static Bitmap getBitmapByDepth(ByteBuffer buffer, int width, int height, float depthValueUnit_mm) {
        byte[] data = new byte[buffer.capacity()];
        buffer.get(data);
        byte[] int4 = new byte[4];
        int[] colors = new int[width * height];
        int set = Color.BLACK - Color.WHITE;
        int z = 0;
        for (int i = 0; i < data.length; i++) {
            if (i % 2 == 0) {
//                int4[0] = data[i];
//                int4[1] = data[i + 1];
//                int4[2] = 0;
//                int4[3] = (byte) 255;
//                int x = (int) (bytesToInt(int4, 0) * depthValueUnit_mm);
//                String s = Integer.toHexString(x);
//                colors[z] = x;
//                colors[z]= getColor(x/1000.f);
//                colors[z]= (int) (Color.BLACK- (x/1000.f)*set);
//                colors[z] = Color.rgb(x, x, x);
                int4[0] = (byte) (255 - data[i]);
                int4[1] = (byte) (255 - data[i + 1]);
                int4[2] = (byte) 255;
                int4[3] = (byte) 255;
                colors[z] = (int) (bytesToInt(int4, 0) * depthValueUnit_mm);
                z++;
            }
        }
        buffer.clear();
        return Bitmap.createBitmap(colors, 0, width, width, height, Bitmap.Config.ARGB_8888);
    }


    public static int bytesToInt(byte[] src, int offset) {
        int value;
        value = (int) ((src[offset] & 0xFF)
                | ((src[offset + 1] & 0xFF) << 8)
                | ((src[offset + 2] & 0xFF) << 16)
                | ((src[offset + 3] & 0xFF) << 24));
        return value;
    }
    static final int TableNum = 768;
    byte[] ColorTableR=new byte[TableNum];
    byte[] ColorTableG=new byte[TableNum];
    byte[] ColorTableB=new byte[TableNum];

    void ColorTableInit()
    {
        float coeff = 256 * 3.0f / ((float)TableNum);
        for (int i = 0; i < TableNum; i++)
        {
            if (i < TableNum / 3)
            {
                ColorTableR[i] = (byte) 255;
                ColorTableG[i] = (byte) (i * coeff);
                ColorTableB[i] = 0;
            }
            else if (i < TableNum * 2 / 3)
            {
                ColorTableR[i] = (byte) (255 - (i - TableNum / 3) * coeff);
                ColorTableG[i] = (byte) 255;
                ColorTableB[i] = (byte) ((i - TableNum / 3) * coeff);
            }
            else
            {
                ColorTableR[i] = 0;
                ColorTableG[i] = (byte) (255 - (i - TableNum * 2 / 3) * coeff);
                ColorTableB[i] = (byte) 255;
            }
        }
    }
//    void Convert::depth2C3Color(uint16_t max_distance, uint16_t min_distance, uint16_t width, uint16_t height, const uint16_t* src, uint8_t* dst)
//    {
//        static std::once_flag flag;
//        std::call_once(flag, ColorTableInit);
//
//        auto* depth = (FormatDepth*)src;
//        auto* pTex  = (FormatRGB888*)dst;
//
//        float colorMapCoeff = (float)TableNum / ((float)(max_distance - min_distance));
//
//        for (int row = 0; row < height; ++row) {
//            for (int col = 0; col < width; ++col, ++pTex, ++depth) {
//                uint16_t pixeldepth = *depth;
//
//                if (pixeldepth >= max_distance || pixeldepth <= min_distance) {
//                    pTex->r = 0;
//                    pTex->g = 0;
//                    pTex->b = 0;
//                }
//                else {
//                    int index = (pixeldepth - min_distance) * colorMapCoeff;
//                    index = std::fmax(std::fmin(index, TableNum - 1), 0);
//
//                    pTex->r = ColorTableR[index];
//                    pTex->g = ColorTableG[index];
//                    pTex->b = ColorTableB[index];
//                }
//            }
//        }
//    }
}
