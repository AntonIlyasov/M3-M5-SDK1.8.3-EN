package com.axtech.functiondemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.Toast;

import org.openni.Device;
import org.openni.DeviceInfo;
import org.openni.ImageRegistrationMode;
import org.openni.OpenNI;
import org.openni.PixelFormat;
import org.openni.SensorType;
import org.openni.VideoFrameRef;
import org.openni.VideoMode;
import org.openni.VideoStream;
import org.openni.android.OpenNIHelper;
import org.openni.android.OpenNIView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

public class ReadFrameThread extends Thread {

    private VideoStream colorStream;
    private VideoStream depthStream;
    private VideoStream irStream;
    private float depthValueUnit_mm;

    public void init() {
        OpenNI.initialize();
    }

    public void shutdown() {
        isStop = true;
        openNIHelper.shutdown();
    }

    @Override
    public void run() {
        super.run();
        while (!isStop) {
            try {
                OpenNI.waitForAnyStream(videoStreamArrayList, 200);
                VideoFrameRef color = colorStream.readFrame();
                VideoFrameRef depth = depthStream.readFrame();
                VideoFrameRef ir = irStream.readFrame();
                if (onCheckDepthPoint != null) {
                    onCheckDepthPoint.callBack(BitmapTransUtils.getDepth(depth.getData(), x, y, depthValueUnit_mm));
                }
                if (capFrameCallBack != null) {
                    switch (cap_type) {
                        case COLOR:
                            capFrameCallBack.onCallBack(BitmapTransUtils.getBitmapByColor(color.getData(), color.getWidth(), color.getHeight()));
                            break;
                        case IR:
                            capFrameCallBack.onCallBack(BitmapTransUtils.getBitmapByIr(ir.getData(), ir.getWidth(), ir.getHeight()));
                            break;
                    }
                    capFrameCallBack = null;
                }
                if (openNIViewColor != null)
                    openNIViewColor.update(color);
                if (openNIViewDepth != null)
                    openNIViewDepth.update(depth);
                if (openNIViewIr != null)
                    openNIViewIr.update(ir);
                color.release();
                depth.release();
                ir.release();
            } catch (TimeoutException e) {
                e.printStackTrace();
            }
        }
        colorStream.destroy();
        depthStream.destroy();
        irStream.destroy();
        OpenNI.shutdown();
    }

    private boolean isStop;
    private OpenNIHelper openNIHelper;
    private Device mDevice;

    public void openDevice(final Context context) {
        openNIHelper = new OpenNIHelper(context);
        List<DeviceInfo> deviceInfos = OpenNI.enumerateDevices();
        if (!deviceInfos.isEmpty()) {
            openNIHelper.requestDeviceOpen(deviceInfos.get(0).getUri(), new OpenNIHelper.DeviceOpenListener() {
                @Override
                public void onDeviceOpened(Device device) {
                    mDevice = device;
                    creatAll();
                    start();
                    Toast.makeText(context, "设备打开成功", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onDeviceOpenFailed(String s) {
                    Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
                }
            });
            Toast.makeText(context, "设备正在打开", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "设备不存在", Toast.LENGTH_SHORT).show();
        }
    }

    private ArrayList<VideoStream> videoStreamArrayList = new ArrayList<>();

    private void creatAll() {
        colorStream = VideoStream.create(mDevice, SensorType.COLOR);
        depthStream = VideoStream.create(mDevice, SensorType.DEPTH);
        irStream = VideoStream.create(mDevice, SensorType.IR);
        videoStreamArrayList.add(colorStream);
        videoStreamArrayList.add(depthStream);
        videoStreamArrayList.add(irStream);
        colorStream.start();
        depthStream.start();
        irStream.start();
        depthValueUnit_mm = OpenNI.getDepthValueUnit_mm(depthStream.getVideoMode().getPixelFormat());
    }

    private int x, y;
    private OpenNIView openNIViewColor;
    private OpenNIView openNIViewDepth;
    private OpenNIView openNIViewIr;

    public void setOpenNIViewColor(OpenNIView view) {
        openNIViewColor = view;
    }

    public void setOpenNIViewDepth(OpenNIView view) {
        openNIViewDepth = view;
    }

    public void setOpenNIViewIr(OpenNIView view) {
        openNIViewIr = view;
    }

    public interface OnCheckDepthPoint {
        void callBack(float depth);
    }

    private OnCheckDepthPoint onCheckDepthPoint;

    public void setOnCheckDepthPoint(int x, int y, OnCheckDepthPoint onCheckDepthPoint) {
        this.x = x;
        this.y = y;
        this.onCheckDepthPoint = onCheckDepthPoint;
    }

    public boolean setImageRegistrationMode(ImageRegistrationMode imageRegistrationMode) {
        if (!mDevice.getDepthColorSyncEnabled()) {
            mDevice.setDepthColorSyncEnabled(true);
        }
        if (mDevice.isImageRegistrationModeSupported(imageRegistrationMode)) {
            mDevice.setImageRegistrationMode(imageRegistrationMode);
            return true;
        }
        return false;
    }

    public Device getmDevice() {
        return mDevice;
    }

    public interface CapFrameCallBack {
        void onCallBack(Bitmap bitmap);
    }

    private CapFrameCallBack capFrameCallBack;
    private SensorType cap_type;

    public void setCapFrameCallBack(SensorType type, CapFrameCallBack callBack) {
        cap_type = type;
        capFrameCallBack = callBack;
    }

    public VideoStream getColorStream() {
        return colorStream;
    }


    public VideoStream getDepthStream() {
        return depthStream;
    }


    public VideoStream getIrStream() {
        return irStream;
    }

}
