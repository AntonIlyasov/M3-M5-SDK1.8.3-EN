package com.axtech.functiondemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.openni.CamParam;
import org.openni.Device;
import org.openni.DeviceInfo;
import org.openni.FWVersion;
import org.openni.Version;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class VersionActivity extends AppCompatActivity {
    private TextView tv_fwversion;
    private TextView tv_drversion;
    private TextView tv_number;
    private TextView tv_deviceinfo;
    private TextView tv_camParam;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_version);
        initUi();
        Device device = readFrameThread.getmDevice();
        FWVersion fwVersion = device.getFWVersion();
        tv_fwversion.setText(getVersionString(fwVersion));
        Version driverVersion = device.getDriverVersion();
        tv_drversion.setText(getVersionString(driverVersion));
        String deviceSerialNumber = device.getDeviceSerialNumber();
        tv_number.setText("SerialNumber: "+deviceSerialNumber);
        DeviceInfo deviceInfo = device.getDeviceInfo();
        tv_deviceinfo.setText("Name: "+deviceInfo.getName()+"\nUri: "+deviceInfo.getUri()+"\nVendor: "+deviceInfo.getVendor()+"\nProductId: "+deviceInfo.getUsbProductId()+"\nVendorId: "+deviceInfo.getUsbVendorId());
        CamParam camParam = device.getCamParam();
        tv_camParam.setText(printCamParam(camParam));
    }
    public String getVersionString(FWVersion fwVersion ){
        return "FWVersion: "+fwVersion.getM_nMajor()+"."+fwVersion.getM_nMinor()+"."+fwVersion.getM_nmaintenance()+"."+fwVersion.getM_nbuild();
    }
    public String getVersionString(Version driverVersion ){
        return "DriverVersion: "+driverVersion.getMajor()+"."+driverVersion.getMinor()+"."+driverVersion.getMajor()+"."+driverVersion.getBuild();
    }
    private String printCamParam(CamParam camParam){
        String s="";
        s+=("color_cx: "+camParam.color_cx+"\n");
        s+=("color_cy: "+camParam.color_cy+"\n");
        s+=("color_fx: "+camParam.color_fx+"\n");
        s+=("color_fy: "+camParam.color_fy+"\n");
        s+=("color_k1: "+camParam.color_k1+"\n");
        s+=("color_k2: "+camParam.color_k2+"\n");
        s+=("color_k3: "+camParam.color_k3+"\n");
        s+=("color_k4: "+camParam.color_k4+"\n");
        s+=("color_k5: "+camParam.color_k5+"\n");
        s+=("color_k6: "+camParam.color_k6+"\n");
        s+=("color_p1: "+camParam.color_p1+"\n");
        s+=("color_p2: "+camParam.color_p2+"\n");
        s+=("color_ResolutionX: "+camParam.color_ResolutionX+"\n");
        s+=("color_ResolutionY: "+camParam.color_ResolutionY+"\n");
        s+=("depth_cx: "+camParam.depth_cx+"\n");
        s+=("depth_cy: "+camParam.depth_cy+"\n");
        s+=("depth_fx: "+camParam.depth_fx+"\n");
        s+=("depth_fy: "+camParam.depth_fy+"\n");
        s+=("depth_k1: "+camParam.depth_k1+"\n");
        s+=("depth_k2: "+camParam.depth_k2+"\n");
        s+=("depth_k3: "+camParam.depth_k3+"\n");
        s+=("depth_k4: "+camParam.depth_k4+"\n");
        s+=("depth_k5: "+camParam.depth_k5+"\n");
        s+=("depth_k6: "+camParam.depth_k6+"\n");
        s+=("depth_p1: "+camParam.depth_p1+"\n");
        s+=("depth_p2: "+camParam.depth_p2+"\n");
        s+=("depth_ResolutionX: "+camParam.depth_ResolutionX+"\n");
        s+=("depth_ResolutionY: "+camParam.depth_ResolutionY+"\n");
        return s;
    }
    private void initUi() {
        tv_fwversion=findViewById(R.id.tv_fwversion);
        tv_drversion=findViewById(R.id.tv_drversion);
        tv_number=findViewById(R.id.tv_number);
        tv_deviceinfo=findViewById(R.id.tv_deviceinfo);
        tv_camParam=findViewById(R.id.tv_camParam);
    }
}
