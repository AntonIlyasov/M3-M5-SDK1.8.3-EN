package com.axtech.functiondemo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.github.angads25.filepicker.controller.DialogSelectionListener;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;

import org.openni.Device;
import org.openni.FWVersion;
import org.openni.FirmWarePacketVersion;
import org.openni.UpgradeStatus;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class ImgfreshActivity extends AppCompatActivity {

    private Device device;
    private String filePath;
    private TextView tv_fwversion;
    private TextView tv_fileversion;
    private TextView tv_state;
    private TextView tv_pick;
    private Button but_pick, but_update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imgfresh);
        device = readFrameThread.getmDevice();
        tv_state = findViewById(R.id.tv_state);
        but_update = findViewById(R.id.but_update);
        but_update.setOnClickListener(onClickListener);
        but_pick = findViewById(R.id.but_pick);
        but_pick.setOnClickListener(onClickListener);
        tv_pick = findViewById(R.id.tv_pick);
        tv_fwversion = findViewById(R.id.tv_fwversion);
        tv_fwversion.setText(getVersionString(device.getFWVersion()));
        tv_fileversion = findViewById(R.id.tv_fileversion);

    }
    public String getVersionString(FWVersion fwVersion ){
        return "FWVersion: "+fwVersion.getM_nMajor()+"."+fwVersion.getM_nMinor()+"."+fwVersion.getM_nmaintenance()+"."+fwVersion.getM_nbuild();
    }


    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.but_update:
                    update();
                    break;
                case R.id.but_pick:
                    pickFile();
                    break;
            }
        }
    };

    private void update() {
        if(TextUtils.isEmpty(filePath)){
            Toast.makeText(this,"请选择文件",Toast.LENGTH_SHORT).show();
            return;
        }
        device.SetUpgradeFile(filePath);
        device.UpgradeEnable(true);
        Toast.makeText(this,"开始更新",Toast.LENGTH_SHORT).show();
        updateUI();
    }

    private void updateUI() {
        tv_state.postDelayed(uiRunnable,500);
    }
    private Runnable uiRunnable=new Runnable() {
        int p=0;
        String point="";
        @Override
        public void run() {
            UpgradeStatus upgradeStatus = device.getUpgradeStatus();
            p++;
            point+=".";
            if(p==8){
                p=0;
                point="";
            }
            if(upgradeStatus==UpgradeStatus.AXON_LINK_SENDFILE_STATUS_SUCCESS){
                tv_state.setText("更新成功 设备自动重启");
                return;
            }
            if(upgradeStatus==UpgradeStatus.AXON_LINK_SENDFILE_STATUS_FAILED){
                tv_state.setText("更新失败");
                return;
            }
            tv_state.setText(upgradeStatus+""+point);
            updateUI();
        }
    };
    private void pickFile() {
        final DialogProperties properties = new DialogProperties();
        properties.selection_mode = DialogConfigs.SINGLE_MODE;
        properties.selection_type = DialogConfigs.FILE_SELECT;
        FilePickerDialog dialog = new FilePickerDialog(this, properties);
        dialog.setTitle("Select a File");
        dialog.setPositiveBtnName("Select");
        dialog.setNegativeBtnName("Cancel");
        dialog.show();
        dialog.setDialogSelectionListener(new DialogSelectionListener() {
            @Override
            public void onSelectedFilePaths(String[] files) {
                FirmWarePacketVersion version = device.getFirmWarePacketVersion(files[0]);
                if (version != null) {
                    filePath = files[0];
                    tv_pick.setText("FilePath: " + files[0]);
                    tv_fileversion.setText("FileVersion "+version.major + "." + version.minor + "." + version.maintenance + "." + version.build);
                } else {
                    tv_pick.setText("FilePath: Not Support");
                }
            }
        });
    }
}
