package com.axtech.functiondemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import org.openni.SensorType;
import org.openni.android.OpenNIView;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class DepthActivity extends AppCompatActivity {
    private OpenNIView oni_view;
    private TextView tv_depth;
    private int x,y;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_depth);
        tv_depth = findViewById(R.id.tv_depth);
        oni_view = findViewById(R.id.oni_view);
        readFrameThread.setOpenNIViewDepth(oni_view);
        oni_view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        x = (int) motionEvent.getX();
                        y = (int) motionEvent.getY();
                        readFrameThread.setOnCheckDepthPoint(x,y,onCheckDepthPoint);
                        break;
                }
                return false;
            }
        });

    }
    ReadFrameThread.OnCheckDepthPoint onCheckDepthPoint=new ReadFrameThread.OnCheckDepthPoint() {
        @Override
        public void callBack(final float depth) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tv_depth.setText(String.format("X:%d Y:%d Depth:%f",x,y,depth));
                }
            });
        }


    };
}
