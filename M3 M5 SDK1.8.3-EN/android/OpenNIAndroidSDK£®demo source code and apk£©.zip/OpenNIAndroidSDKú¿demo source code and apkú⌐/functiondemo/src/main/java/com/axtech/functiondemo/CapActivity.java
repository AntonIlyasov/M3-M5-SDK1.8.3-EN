package com.axtech.functiondemo;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import org.openni.SensorType;
import org.openni.android.OpenNIView;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class CapActivity extends AppCompatActivity {
    private ImageView iv_ir;
    private ImageView iv_color;
    private Button but_capcolor, but_capir;
    private OpenNIView oni_color;
    private OpenNIView oni_ir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cap);
        iv_color = findViewById(R.id.iv_color);
        iv_ir = findViewById(R.id.iv_ir);
        but_capcolor = findViewById(R.id.but_capcolor);
        but_capir = findViewById(R.id.but_capir);
        but_capcolor.setOnClickListener(listener);
        but_capir.setOnClickListener(listener);
        oni_ir = findViewById(R.id.oni_ir);
        oni_color = findViewById(R.id.oni_color);
        readFrameThread.setOpenNIViewIr(oni_ir);
        readFrameThread.setOpenNIViewColor(oni_color);
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.but_capcolor:
                    readFrameThread.setCapFrameCallBack(SensorType.COLOR, new ReadFrameThread.CapFrameCallBack() {
                        @Override
                        public void onCallBack(final Bitmap bitmap) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    iv_color.setImageBitmap(bitmap);
                                }
                            });
                        }
                    });
                    break;
                case R.id.but_capir:
                    readFrameThread.setCapFrameCallBack(SensorType.IR, new ReadFrameThread.CapFrameCallBack() {
                        @Override
                        public void onCallBack(final Bitmap bitmap) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    iv_ir.setImageBitmap(bitmap);
                                }
                            });
                        }
                    });
                    break;
            }

        }
    };
}
