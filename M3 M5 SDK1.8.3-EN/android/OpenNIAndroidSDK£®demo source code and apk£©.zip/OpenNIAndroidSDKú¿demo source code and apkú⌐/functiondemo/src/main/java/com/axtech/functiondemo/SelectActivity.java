package com.axtech.functiondemo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class SelectActivity extends AppCompatActivity {
    public static ReadFrameThread readFrameThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, MYREUEST);
    }

    public void onclik(View view) {
        switch (view.getId()) {
            case R.id.but_init:
                initDevice();
                break;
            case R.id.but_align:
                startActivity(new Intent(this, AlignActivity.class));
                break;
            case R.id.but_depth:
                startActivity(new Intent(this, DepthActivity.class));
                break;
            case R.id.but_version:
                startActivity(new Intent(this, VersionActivity.class));
                break;
            case R.id.but_write:
                startActivity(new Intent(this, ImgfreshActivity.class));
                break;
            case R.id.but_cap:
                startActivity(new Intent(this, CapActivity.class));
                break;
            case R.id.but_dpi:
                startActivity(new Intent(this, DpiActivity.class));
                break;
            case R.id.but_dsp:
                startActivity(new Intent(this, DspActivity.class));
                break;
        }
    }
    private void initDevice(){
        readFrameThread = new ReadFrameThread();
        readFrameThread.init();
        readFrameThread.openDevice(getApplicationContext());
    }
    private final int MYREUEST = 1001;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode) {
            case MYREUEST: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    Toast.makeText(this, "Need Permission", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(readFrameThread!=null)
        readFrameThread.shutdown();
    }
}
