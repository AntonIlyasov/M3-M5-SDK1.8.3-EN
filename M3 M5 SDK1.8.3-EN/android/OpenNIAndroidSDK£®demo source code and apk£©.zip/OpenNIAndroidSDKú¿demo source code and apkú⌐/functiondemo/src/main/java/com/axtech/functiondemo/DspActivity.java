package com.axtech.functiondemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;

import org.openni.AXonDSPInterface;
import org.openni.android.OpenNIView;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class DspActivity extends AppCompatActivity {

    private LinearLayout dsp_layout;
    private OpenNIView oni_color,oni_depth,oni_ir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dsp);
        dsp_layout = findViewById(R.id.dsp_layout);
        oni_color = findViewById(R.id.oni_color);
        oni_depth = findViewById(R.id.oni_depth);
        oni_ir = findViewById(R.id.oni_ir);
        readFrameThread.setOpenNIViewColor(oni_color);
        readFrameThread.setOpenNIViewDepth(oni_depth);
        readFrameThread.setOpenNIViewIr(oni_ir);
        init();
    }
    private  AXonDSPInterface[] values;
    private void init(){
        values= AXonDSPInterface.values();
        for(AXonDSPInterface dsp:values){
            CheckBox button=new CheckBox(this);
            button.setText(dsp+"");
            button.setTag(dsp);
            button.setOnCheckedChangeListener(onCheckedChangeListener);
            dsp_layout.addView(button);
        }
    }
    private CompoundButton.OnCheckedChangeListener onCheckedChangeListener= new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            AXonDSPInterface ai= (AXonDSPInterface) compoundButton.getTag();
            int dspInterfaceStatus = readFrameThread.getmDevice().getDSPInterfaceStatus();
            readFrameThread.getmDevice().setDSPInterfaceStatus(ai,b?1:0);
        }
    };
    private View.OnClickListener listener=new View.OnClickListener() {
        @Override
        public void onClick(View view) {

        }
    };
//      System.out.println("第一种通过反射");
//    Class<EnumsTest> clz=EnumsTest.class;
//	     for(EnumsTest obj:clz.getEnumConstants()){
//        System.out.println(obj.getType());
//    }
//
//	     System.out.println("第二种通过枚举静态方法values()");
//	        for(EnumsTest rate:EnumsTest.values()){
//        System.out.println(rate.getType());
//    }
}

