package com.axtech.functiondemo;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.openni.Device;
import org.openni.ImageRegistrationMode;
import org.openni.OpenNI;
import org.openni.SensorType;
import org.openni.Version;
import org.openni.VideoFrameRef;
import org.openni.VideoStream;
import org.openni.android.OpenNIHelper;
import org.openni.android.OpenNIView;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.concurrent.TimeoutException;

public class MainActivity extends AppCompatActivity {
    private OpenNIView openiView;
    private OpenNIHelper openNIHelper;
    private Device mDevice;
    private VideoStream colorStream;
    private VideoStream depthStream;
    private VideoStream irStream;
    private TextView tv_check;
    private Button but_check;
    private ImageView iv_img;
    private int type=0;
    private   int imageRegistrationType;
    private ImageRegistrationMode[] imageRegistrationModes={ImageRegistrationMode.OFF,ImageRegistrationMode.COLOR_TO_DEPTH,ImageRegistrationMode.DEPTH_IR_TO_COLOR,ImageRegistrationMode.DEPTH_TO_COLOR,ImageRegistrationMode.COLOR_UNDISTORTION_ONLY};
    private float depthValueUnit_mm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        OpenNI.initialize();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv_img=findViewById(R.id.iv_img);
        tv_check=findViewById(R.id.tv_check);
        but_check=findViewById(R.id.but_check);
        but_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageRegistrationType++;
                if(imageRegistrationType%imageRegistrationModes.length==0){
                    imageRegistrationType=0;
                }
                boolean imageRegistrationModeSupported = mDevice.isImageRegistrationModeSupported(imageRegistrationModes[imageRegistrationType]);
                if(imageRegistrationModeSupported){
                    mDevice.setImageRegistrationMode(imageRegistrationModes[imageRegistrationType]);
                }else {
                    Toast.makeText(MainActivity.this,"不支持"+imageRegistrationModes[imageRegistrationType],Toast.LENGTH_SHORT).show();
                }
                tv_check.setText(""+imageRegistrationModes[imageRegistrationType]);
            }
        });
        openiView=findViewById(R.id.openiView);
        openiView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type++;
                if(type%3==0){
                    type=0;
                }
            }
        });
        openNIHelper = new OpenNIHelper(this);
        if(!OpenNI.enumerateDevices().isEmpty()){
            openNIHelper.requestDeviceOpen(OpenNI.enumerateDevices().get(0).getUri(), new OpenNIHelper.DeviceOpenListener() {
                @Override
                public void onDeviceOpened(Device device) {
                    mDevice=device;
                    Version driverVersion = mDevice.getDriverVersion();
                    Log.i("CHECK", "driver version" + driverVersion.getMajor() + driverVersion.getMinor() + driverVersion.getMaintenance());
                    colorStream = VideoStream.create(mDevice, SensorType.COLOR);
                    depthStream = VideoStream.create(mDevice, SensorType.DEPTH);
                    irStream = VideoStream.create(mDevice, SensorType.IR);
                    mDevice.setDepthColorSyncEnabled(true);
                    videoStreamArrayList.add(colorStream);
                    videoStreamArrayList.add(depthStream);
                    videoStreamArrayList.add(irStream);
                    colorStream.start();
                    depthStream.start();
                    irStream.start();
                    depthValueUnit_mm = OpenNI.getDepthValueUnit_mm(depthStream.getVideoMode().getPixelFormat());
                    readFrameThread.start();
                }

                @Override
                public void onDeviceOpenFailed(String s) {
                    Log.e("CHECK",s);
                }
            });
        }
    }
    ArrayList<VideoStream> videoStreamArrayList=new ArrayList<>();
    private boolean isRun=true;
    private Thread readFrameThread=new Thread(new Runnable() {
        @Override
        public void run() {
            while (isRun){
                try {
                    OpenNI.waitForAnyStream(videoStreamArrayList,200);
                } catch (TimeoutException e) {
                    e.printStackTrace();
                    continue;
                }
                VideoFrameRef colorFrame = colorStream.readFrame();
                VideoFrameRef depthFrame = depthStream.readFrame();
                VideoFrameRef irFrame = irStream.readFrame();
                ByteBuffer depthFrameData = depthFrame.getData();
                ByteBuffer irFrameData = irFrame.getData();
                long time = System.currentTimeMillis();
                final Bitmap irbitmap=BitmapTransUtils.getBitmapByIr(irFrameData,640,480);
                Log.e("CHECK",(System.currentTimeMillis()-time)+" irbitmap");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        iv_img.setImageBitmap(irbitmap);
                    }
                });
                switch (type){
                    case 0:
                        openiView.update(colorFrame);
                        break;
                    case 1:
                        openiView.update(depthFrame);
                        break;
                    case 2:
                        openiView.update(irFrame);
                        break;
                }

                colorFrame.release();
                depthFrame.release();
                irFrame.release();
            }
            colorStream.destroy();
            depthStream.destroy();
            irStream.destroy();
            OpenNI.shutdown();
        }
    });

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isRun=false;
        openNIHelper.shutdown();
    }
}
