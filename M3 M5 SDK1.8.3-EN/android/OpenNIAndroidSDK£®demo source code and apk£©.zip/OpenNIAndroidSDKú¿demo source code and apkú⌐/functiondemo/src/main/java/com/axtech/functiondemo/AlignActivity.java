package com.axtech.functiondemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.openni.ImageRegistrationMode;
import org.openni.android.OpenNIView;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class AlignActivity extends AppCompatActivity {
    private OpenNIView oni_color,oni_depth,oni_ir;
    private ImageRegistrationMode[] imageRegistrationModes={ImageRegistrationMode.OFF,ImageRegistrationMode.COLOR_TO_DEPTH,ImageRegistrationMode.DEPTH_IR_TO_COLOR,ImageRegistrationMode.DEPTH_TO_COLOR,ImageRegistrationMode.COLOR_UNDISTORTION_ONLY};
    private Button but_check;
    private TextView tv_check;
    private int imageRegistrationType;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_align);
        oni_color=findViewById(R.id.oni_color);
        oni_depth=findViewById(R.id.oni_depth);
        tv_check=findViewById(R.id.tv_check);
        oni_ir=findViewById(R.id.oni_ir);
        readFrameThread.setOpenNIViewColor(oni_color);
        readFrameThread.setOpenNIViewDepth(oni_depth);
        readFrameThread.setOpenNIViewIr(oni_ir);
        but_check=findViewById(R.id.but_check);
        but_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageRegistrationType++;
                if(imageRegistrationType%imageRegistrationModes.length==0){
                    imageRegistrationType=0;
                }
                boolean isSupported = readFrameThread.setImageRegistrationMode(imageRegistrationModes[imageRegistrationType]);
                if(!isSupported){
                    Toast.makeText(AlignActivity.this,"不支持"+imageRegistrationModes[imageRegistrationType],Toast.LENGTH_SHORT).show();
                }
                tv_check.setText(""+imageRegistrationModes[imageRegistrationType]);
            }
        });
    }
}
