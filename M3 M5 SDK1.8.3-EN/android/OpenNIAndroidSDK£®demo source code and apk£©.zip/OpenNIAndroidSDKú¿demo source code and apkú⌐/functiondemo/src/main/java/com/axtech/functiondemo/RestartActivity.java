package com.axtech.functiondemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.axtech.functiondemo.SelectActivity.readFrameThread;

public class RestartActivity extends AppCompatActivity {
    private Button  restart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restart);
        restart=findViewById(R.id.but_reset);
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readFrameThread.getmDevice().reboot();
            }
        });
    }
}
